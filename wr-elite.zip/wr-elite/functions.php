<?php
/**
 * @version    1.6
 * @package    Theme
 * @author     Ibadur Rehman
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 *
 */

// Initialize theme
include_once get_template_directory() . '/inc/init.php';