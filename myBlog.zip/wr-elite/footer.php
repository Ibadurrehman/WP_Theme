<?php
/**
 * @version    1.6
 * @package    Theme
 * @author     Ibadur Rehman
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 *
 */
?>
			</div><!-- .container -->

		</div><!-- #content -->

		<footer id="colophon" class="site-footer" <?php wr_elite_schema_metadata( array( 'context' => 'footer' ) ); ?>>
			<div class="container">
				<!-- .logo-footer -->
				<div class="site-info">
					<?php echo ent2ncr( wr_elite_theme_option( 'wr_footer_info' ) ); ?>
				</div><!-- .site-info -->
			</div>
		</footer><!-- #colophon -->
	</div><!-- .container -->
	<a href="#" class="back-to-top"><i class="icon-angle-up"></i></a>
</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>
